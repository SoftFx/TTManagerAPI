library(testthat)
library(rClr)
setRDotNet(TRUE)
cTypename <- "Rclr.TestCases"
testClassName <- "Rclr.TestObject"
