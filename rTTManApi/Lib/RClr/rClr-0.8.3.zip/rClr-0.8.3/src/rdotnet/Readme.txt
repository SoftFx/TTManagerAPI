2014-06-01 
This folder used to version source code for R.NET. rClr now uses updated packages at NuGet.org instead.